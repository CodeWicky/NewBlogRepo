
---

title: 老司机读书笔记——Effective Objective-C 2.0阅读笔记
layout: post
date: 2017-06-21 07:33:44
updated: 2017-06-21 07:33:44
tags: 
- 笔记 
categories: 阅读笔记

---
![Effective Objective-C 2.0阅读笔记](http://or3w6eypz.bkt.clouddn.com/blogPic/effectiveOC/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202017-06-21%20%E4%B8%8A%E5%8D%8810.52.11.png)

这篇文章你将看到以下内容：
- Efficetive Objective-C 2.0阅读笔记一些有价值的建议

<!-- more -->

- - - 

### 对象内部尽量直接访问实例变量
直接访问实例变量为直接访问内存，效率比调用属性高。

- 访问实例变量不会触发KVO
- `-init`及`-dealloc`方法中应使用实例变量
- 对象内部应尽量遵守如下原则：取值采用实例变量，赋值采用属性。

- - -
### 消息转发机制流程
![消息转发流程](http://or3w6eypz.bkt.clouddn.com/blogPic/effectiveOC/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202017-06-20%20%E4%B8%8B%E5%8D%885.24.16.png)

- - -
### 尽量使用不可变对象
- 集合中尽量添加不可变对象，否则可能会发生与集合本身语义有分歧的后果，eg：

```
NSMutableArray * arr1 = @[@1].mutableCopy;
NSMutableArray * arr2 = @[@1,@2].mutableCopy;
NSSet * set = [NSSet setWithObjects:arr1,arr2, nil];
[arr1 addObject:@2];//至此set中居然包含了两个相同的元素
NSSet * setCopy = [set copy];//书中此处表述setCopy应只有一个元素，然实测有两个相同元素
```

- 对象对外公开集合类尽量使用不可变集合
- 对象对外公开`readOnly`属性，内部可以通过重新声明为`readWrite`来使用属性值。**如此操作后和能会由于竞态使得部分情况外部可以修改属性值，外部也可通过KVC来更改属性值**

- - -
### 将类的实现代码分散到便于管理的数个分类之中
> 通过分类机制，可以把类代码分成很多个易于管理的小块，以便单独检视。
> 
> 之所以要将类代码打散到分类中还有个原因，就是便于调试：对于某个分类中的所有方法来说，分类名称都会出现在其符号中。
> 
> 将应该视为“私有”的方法归入名叫Private的分类中，以隐藏实现细节。

- - -
### 在-dealloc中只释放引用并解除监听

- 在`-dealloc`方法里，应该做的事情就是释放指向其他对象的引用，并取消原来订阅的“键值观测”（KVO）或NSNotificationCenter等通知，不要做其他事情。
- 如果对象持有文件描述符等系统资源，那么应该专门编写一个方法来释放此种资源。这样的类要和其他使用者约定：用完资源后必须调用close方法。
- 执行异步任务的方法不应再`-dealloc`里调用；只能子啊正常状态下执行的那些方法也不应在`-dealloc`里调用，因为此时对象已处于正在回收的状态了。

- - -
### 以自动释放池降低内存峰值
比方说，在循环中不断地创建的临时对象。即便这些对象在调用完方法之后就就不在使用了，他们也依然处于存活状态，因为目前还在自动释放池里，等待系统稍后将其释放并回收。然而，自动释放池要等线程执行下一次runLoop时才会清空。这样依赖，执行for循环时，应用程序所占内存量就会持续上涨，而等到所有临时对象都释放后，内存用量又会突然下降。

然而在循环中合理的位置添加自动释放池，应用程序在执行循环时的内存峰值就会降低。

- - -
### 多用派发队列，少用同步锁

滥用`@synchronized(self)`会降低代码效率，因为共用同一个锁的那些同步块，都必须按顺序执行。若想实现同步机制，可以以并行队列、同步任务及栅栏实现，代码如下：

```
_syncQueue = dispatch_queue_create("com.syncQ.Wicky", DISPATCH_QUEUE_CONCURRENT);///创建并行队列

///getter
-(NSString *)someString {
    __block NSString * localString;
    dispatch_sync(_syncQueue, ^{
        localString = _someString;
    });
    return localString;
}

///setter
-(void)setSomeString:(NSString *)someString {
    dispatch_barrier_async(_syncQueue, ^{
        _someString = someString;
    });
}
```

- - -
### 多用GCD，少用performSelector系列方法
由于在编译器无法确定performSelector方法是否具有返回值，故编译器没有对对象进行引用计数管理，因此可能造成内存泄漏。

另外performSelector返回值只能是id类型的对象，基本数据类型可能需要开发人员进行进一步的类型转换。

如果想要添加延时任务，条件允许的情况下应尽可能选择GCD。

- - - 
### 合理使用GCD与NSOperation
GCD为纯C的API，而NSOperation则是OC对象。与NSOperation比起来GCD更加轻量，然而NSOperation却有以下几点在使用上更加便捷：

- 取消操作
- 指定依赖关系
- 提供KVO监听
- 指定优先级
- 重用对象

- - - 
### 多用Block枚举，少用for循环
Block枚举拥有其他遍历方式具备的所有优势，而且还能带来更多好处。与快速遍历法相比，他还要多用一些代码，可是却能提供遍历时所针对的下标，在遍历字典时也能同时提供键与值，而且还有选项可以开启并发迭代功能，所以多写这点代码还是值得的。

- - -
### 精简+initialize与+load的实现代码
- 在加载阶段，如果类实现了`+load`方法，那么系统就会先调用他。分类里也可以定义此方法，类的`+load`方法要比分类中的先调用。与其他方法不同，`+load`方法不参与覆写机制。
- 首次使用某个类之前，系统会向其发送`+initialize`消息。由于此方法遵从普通的覆写机制，所以通常应该在里面判断当前要初始化的是哪个类。
- `+load`与`+initialize`方法都应该实现的精简一些，这有助于保持应用程序的响应能力，也能减少引入“依赖环”的几率。
- 无法在编译器设定的全局常量，可以放在`+initialize`方法里初始化。
